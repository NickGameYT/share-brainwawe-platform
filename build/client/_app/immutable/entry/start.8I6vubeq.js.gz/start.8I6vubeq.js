import{b as a}from"../chunks/entry.DaBXfuHJ.js";export{a as start};
