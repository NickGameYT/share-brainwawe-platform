import{b as a}from"../chunks/entry.BauIi3_i.js";export{a as start};
